;(function ($) {
	var optionDefaults = {
		style:''
	};
	$.fn.timeShow = function( option ){
		var obj = new TimeShow( $(this));
		obj.init(option);
	};

	//���캯��
	function TimeShow( $element){
		this.$element = $element ; //����ͼ�길�� html �ڵ�
	};

	TimeShow.prototype = {
		init : function(config){
			var ele = this.$element;
			var style = config.style;
			var obj = this;
			function change(){
				
				switch(style){
					case "style1":
						ele.html(obj.style1());
					break;
					case "style2":
						ele.html(obj.style2());
					break;
					case "style3":
						ele.html(obj.style3());
					break;
					case "style4":
						ele.html(obj.style4());
						
					break;
					default:
						ele.html(obj.style1());
					break;
				}
				var valign = ele.css("vertical-align");
						switch(valign){
							case "middle":
								var pv = parseInt(ele.css("height"));
								var cv = parseInt(ele.children().css("height"));
								ele.children().css("margin-top",(pv-cv)/2 + "px");
							break;
							case "bottom":
								var pv = parseInt(ele.css("height"));
								var cv = parseInt(ele.children().css("height"));
								ele.children().css("margin-top",(pv-cv) + "px");
							break;
						}
				setTimeout(function(){change();},60 *1000);
			}
			change();
		},
		style1: function(){
			return "<div>" + currentTime() + "</div>";
		},
		style2: function(){
			var d = new Date();
			var hour = d.getHours();   
			var minutes = d.getMinutes(); 
			var year = d.getFullYear(); 
			var month = d.getMonth() + 1; 
			var day = d.getDate(); 
			return  "<div>" + year + "/" + (month < 10 ? ("0" + month) : month) + "/" + (day < 10 ? ("0" + day) : day) + " " + (hour < 10 ? ("0" + hour) : hour) + ":" + (minutes < 10 ? ("0" + minutes) : minutes) + "</div>"
		},
		style3: function(){
			var d = new Date();
			var hour = d.getHours();   
			var minutes = d.getMinutes(); 
			var year = d.getFullYear(); 
			var month = d.getMonth() + 1; 
			var day = d.getDate();
			var fs = parseInt(this.$element.css("fontSize")) * 2 + "px";
			return  "<div><div style='font-size:" + fs + ";'>"+(hour < 10 ? ("0" + hour) : hour) + ":" + (minutes < 10 ? ("0" + minutes) : minutes) + "</div><div>" +  year + "-" + (month < 10 ? ("0" + month) : month) + "-" + (day < 10 ? ("0" + day) : day) + "</div></div>";
		},
		style4: function(){
			var m=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Spt","Oct","Nov","Dec");
			var w=new Array("Monday","Tuseday","Wednesday","Thursday","Friday","Saturday","Sunday");
			var d = new Date();
			var hour = d.getHours();   
			var minutes = d.getMinutes(); 
			var mn = d.getMonth();
			var wn = d.getDay();
			var dn = d.getDate();
			var fs = parseInt(this.$element.css("fontSize")) * 2 + "px";
			var pad = parseInt(this.$element.css("fontSize")) * 0.25 + "px";
			var align = this.$element.css("text-align");
			return "<table border='0' cellspacing='0' cellpadding='0'  align='" + align + "'><tr><td rowspan='2' width='50%' align='right' style='padding-right:"+pad+";font-size:" + fs + ";'>" + (hour < 10 ? ("0" + hour) : hour) + ":" + (minutes < 10 ? ("0" + minutes) : minutes) + "</td><td align='left' valign='bottom' style='padding-left:"+pad+";'>"+ w[wn-1] +"</td></tr> <tr><td align='left' valign='top'>" + m[mn] + " " + dn + "</td></tr></table>";
		}

	};
})(jQuery);