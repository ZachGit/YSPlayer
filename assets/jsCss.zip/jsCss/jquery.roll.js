﻿//(function ($) {
//    $.fn.extend({
//        roll: function (option) {
//            var defaults = { speed: 1, marqueeId: "", text: "" };
//            var options = $.extend(defaults, option);
//            var speed = (document.all) ? options.speed : Math.max(1, options.speed - 1);
//            if ($(this) == null) {
//                return;
//            }
//            var $container = $(this);
//            var $content = $("#" + defaults.marqueeId);
//            $("#" + defaults.marqueeId).html(defaults.text);
//            var init_left = $container.width();
//            $content.css({ left: parseInt(init_left) + "px" });
//            var me = this;
//            var time = setInterval(function () { me.move($container, $content, speed); }, 20);
//            //setInterval会改变this指向，me=this，也要用匿名函数封装，这里调试了n久
//            $container.bind("mouseover", function () {
//                clearInterval(time);
//            });
//            $container.bind("mouseout", function () {
//                time = setInterval(function () { me.move($container, $content, speed); }, 20);
//            });
//            return this;
//        },
//        move: function ($container, $content, speed) {
//            var container_width = $container.width();
//            var content_width = $content.width();
//            if (parseInt($content.css("left")) + content_width > 0) {
//                $content.css({ left: parseInt($content.css("left")) - speed + "px" });
//            } else {
//                $content.css({ left: parseInt(container_width) + "px" });
//            }
//        }
//    });
//})(jQuery);

(function ($) {
    $.fn.extend({
        roll: function (option) {
            var defaults = {
                width: "960px",
                height: "300px",
                scrollamount: "10",
                direction: "left",
                scrolldelay: "10",
                bgcolor: "",
                behavior: "scroll",
                text: ""
            };
            var options = $.extend(defaults, option);
            var id = $(this).attr("id");

            var b = checkBrowser();
            if (b == "ie5" || b == "ie6" || b == "ie7" || b == "ie8") {
                var html = "<marquee id=\"marquee_" + id + "\" width=\"" + options.width + "\" height=\"" + options.height + "\" align=\"Bottom\" behavior=\"" + options.behavior + "\" direction=\"" + options.direction + "\" scrollamount=\"" + options.scrollamount + "\" scrolldelay=\"" + options.scrolldelay + "\" >" + options.text + "</marquee>";
                $(this).html(html);
                $(this).css('line-height', $(this).height() + 'px');
            }
            else {
                var html = "<marquee id=\"marquee_" + id + "\" width=\"" + options.width + "\" height=\"" + options.height + "\" align=\"Bottom\" behavior=\"" + options.behavior + "\" direction=\"" + options.direction + "\" scrollamount=\"" + options.scrollamount + "\" scrolldelay=\"" + options.scrolldelay + "\" ><table width=\"100%\" height=\"100%\"><tr><td valign=\"middle\">" + options.text + "</td></tr></table></marquee>";
                $(this).html(html);
            }
        }
    });
})(jQuery);