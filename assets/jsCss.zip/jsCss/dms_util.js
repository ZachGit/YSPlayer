/**
 * ����ѭ���ֲ�
 * @param {Object} tb
 */
function replay(subid) {
    if ($('#'+subid+' tr').length > num) {
        $('#'+subid+' tr').each(function(){
            if ($(this).css('display') == 'none') {
                $(this).css('display','');
            } else {
                $(this).css('display','none');
            }
        });
    }   
}

/**
 * ��ʾ��������
 * @param {Object} tb
 * @param {Object} data
 */
function init(subid, data) {
    var tbodyObj = $('<tbody></tbody>');
    var dataArr = data.split(',');
    for (var i = 0; i < dataArr.length; i++) {
        // �����ж���
        var rowObj = $('<tr></tr>');
		rowObj.className='tr2';
        if (i >= num) {
            rowObj.css('display','none');
        }
        // ��������
        var arr = dataArr[i].split('|');
        for (var j = 0; j < arr.length; j++) {
			if(i==0){
            if(j==0){
                var itemObj = $('<td></td>');
                itemObj.className='td1';
                itemObj.style.width='117px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);
            } else if(j==1){
                var itemObj = $('<td></td>');
                itemObj.className='td2';
                itemObj.style.width='162px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            } else if(j==2){
                var itemObj = $('<td></td>');
                itemObj.className='td1';
                itemObj.style.width='164px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            } else if(j==3){
                var itemObj = $('<td></td>');
                itemObj.className='td2';
                itemObj.style.width='160px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            } else if(j==4){
                var itemObj = $('<td></td>');
                itemObj.className='td1';
                itemObj.style.width='159px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            }				
			}else{
            if(j==0){
                var itemObj = $('<td></td>');
                itemObj.className='td3';
                itemObj.style.width='117px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);
            } else if(j==1){
                var itemObj = $('<td></td>');
                itemObj.className='td4';
                itemObj.style.width='162px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            } else if(j==2){
                var itemObj = $('<td></td>');
                itemObj.className='td3';
                itemObj.style.width='164px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            } else if(j==3){
                var itemObj = $('<td></td>');
                itemObj.className='td4';
                itemObj.style.width='160px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            } else if(j==4){
                var itemObj = $('<td></td>');
                itemObj.className='td3';
                itemObj.style.width='159px';
                itemObj.style.height='126px';
                itemObj.append(arr[j]);
                rowObj.append(itemObj);             
            }				
			}
        }
        tbodyObj.append(rowObj);
    }
    // �������
    $('#'+subid).html('');
    // ��������
    $('#'+subid).append(tbodyObj);
}

/**
 * ���ݲ����ļ���׺�����ļ�����ˢ�²�����
 * @param {Object} type �����ļ���׺��
 * @param {Object} file �ļ���
 */
function flushPlay(subid,type,file){
	var obj=document.getElementById(subid);
	var objParent = obj.parentNode;
	if(type=="avi"){
		obj.stop();
		objParent.removeChild(obj);
		objParent.innerHTML='<object id=\"obj\" width=\"427\" height=\"221\" border=\"0\" classid=\"clsid:22d6f312-b0f6-11d0-94ab-0080c74c7e95\"><param name=\"ShowDisplay\" value=\"0\" /><param name=\"ShowControls\" value=\"0\" /><param name=\"AutoStart\" value=\"1\" /><param name=\"AutoRewind\" value=\"0\" /><param name=\"PlayCount\" value=\"0\" /><param name=\"Appearance\" value=\"0\"><param name=\"BorderStyle\" value=\"0\"><param name=\"MovieWindowHeight\" value=\"221\" /><param name=\"MovieWindowWidth\" value=\"427\" /><param name=\"FileName\" value=\"'+file+'\" /><embed width=\"427\" height=\"221\" border=\"0\" showdisplay=\"0\" showcontrols=\"0\" autostart=\"1\" autorewind=\"0\" playcount=\"0\" moviewindowheight=\"221\" moviewindowwidth=\"427\" src=\"'+file+'\"> </embed></object>';
	}else if(type=="swf"){
        obj.stop();
		objParent.removeChild(obj);
        objParent.innerHTML='<object id=\"obj\" classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\"427\" height=\"221\"><param name=\"movie\" value=\"'+file+'\"><param name=\"quality\" value=\"high\"><param name=\"wmode\" value=\"opaque\" /><embed src=\"'+file+'\" quality=\"high\" wmode=\"opaque\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" width=\"427\" height=\"221\"></embed></object>';		
	}else if(type=="wmv"){
        obj.stop();
		objParent.removeChild(obj);
        objParent.innerHTML='<object id=\"obj\" name=\"MediaPlayer\" width=\"427\" height=\"221\" CLASSID=\"CLSID:6BF52A52-394A-11d3-B153-00C04F79FAA6\" codeBase=http://www.aaa.com/play/nsmp2inf.cab#Version=6,1,5,240 type=application/x-oleobject standby=\"Loading Microsoft Windows Media Player components...\"> <param name=\"URL\" value=\"'+file+'\"> <param name=\"rate\" value=\"1\"> <param name=\"balance\" value=\"0\"> <param name=\"currentPosition\" value=\"0\"> <param name=\"defaultFrame\" value> <param name=\"playCount\" value=\"100\"> <param name=\"autoStart\" value=\"-1\"> <param name=\"currentMarker\" value=\"0\"> <param name=\"uiMode\" value=\"none\"></object>';		
	}
}

/**
 * ˢ���ı�������
 * @param {Object} sunid
 * @param {Object} data
 */
function flushText(sunid,data){
	    // �������
    $('#'+subid).html('');
    // ��������
    $('#'+subid).append(data);
}

/**
 * ����subid��file��ˢ��ͼƬ������
 * @param {Object} subid
 * @param {Object} file
 */
function flushpic(subid,file){
	var obj=document.getElementById(subid);
	var objParent = obj.parentNode;
	objParent.removeChild(obj);
	objParent.innerHTML='<object id=\"'+subid+'\" classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0\" width=\"468\" height=\"312\"><param name=\"movie\" value=\"bcastr3.swf\"><param name=\"quality\" value=\"high\"><param name=\"wmode\" value=\"transparent\"><param name=\"FlashVars\" value=\"bcastr_file='+file+'\"><embed  src=\"bcastr3.swf\" FlashVars=\"bcastr_file='+file+'\" width=\"468\" height=\"312\" loop=\"false\" quality=\"high\" pluginspage=\"http://www.macromedia.com/go/getflashplayer\" type=\"application/x-shockwave-flash\" salign=\"T\" name=\"scriptmain\" menu=\"false\" wmode=\"transparent\"></embed></object>';
}

