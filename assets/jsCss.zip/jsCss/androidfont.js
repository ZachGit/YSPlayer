﻿var fonts = [];
fonts["宋体"] = ["宋体_斜", "宋体_粗", "宋体_斜_粗"];
fonts["黑体"] = ["黑体_斜", "黑体_粗", "黑体_斜_粗"];
fonts["微软雅黑"] = ["微软雅黑_斜", "微软雅黑_粗", "微软雅黑_斜_粗"];
fonts["微软正黑体"] = ["微软正黑体_斜", "微软正黑体_粗", "微软正黑体_斜_粗"];
fonts["细明体"] = ["细明体_斜", "细明体_粗", "细明体_斜_粗"];
fonts["仿宋"] = ["仿宋_斜", "仿宋_粗", "仿宋_斜_粗"];
fonts["楷体"] = ["楷体_斜", "楷体_粗", "楷体_斜_粗"];

function changeFont() {
	for (var i = 0; i < document.styleSheets.length; i++) {
		var csslist = document.styleSheets[i];

		if (!csslist.readOnly && csslist.href == null && csslist.rules != null) {

			for (var j = 0; j < csslist.rules.length; j++) {

				if (csslist.rules[j].style.fontFamily != "") {


					var ff = csslist.rules[j].style.fontFamily;
					if (ff != '宋体' || ff != '黑体' || ff != '楷体') {
						csslist.rules[j].style.fontFamily = '宋体';
					}
					/*if (fonts[ff] == null) {
						continue;
					}
					var isB = false;
					var isI = false;
					var fw = csslist.rules[j].style.fontWeight.toLowerCase();
					if (fw == "bold" || fw == "bolder") {
						isB = true;
					}
					var fs = csslist.rules[j].style.fontStyle.toLowerCase();
					if (fs == "italic") {
						isI = true;
					}

					if (isB && isI) {
						csslist.rules[j].style.fontFamily = fonts[ff][2];
					} else if (isB) {
						csslist.rules[j].style.fontFamily = fonts[ff][1];
					}
					else if (isI) {
						csslist.rules[j].style.fontFamily = fonts[ff][0];
					}*/

				}
			}
		}
	}
}