//����QueryString�������ƻ�ȡֵ

function getQueryStringByName(name) {

    var result = location.search.match(new RegExp("[\?\&]" + name + "=([^\&]+)", "i"));

    if (result == null || result.length < 1) {

        return "";

    }

    return result[1];

}

//��������
function checkBrowser() {
    var Sys = {};
    var ua = navigator.userAgent.toLowerCase();
    var s;

    (s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] : (s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] : (s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] : (s = ua.match(/opera.([\d.]+)/)) ? Sys.opera = s[1] : (s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;
    if (Sys.ie) {
        if (Sys.ie == '9.0') {
            return "ie9";
        }
        else if (Sys.ie == '8.0') {
            return "ie8";
        }
        else {
            return "ie7";
        }
    }
    if (Sys.firefox) {//Js�ж�Ϊ���(firefox)�����
        return "firefox";
    }
    if (Sys.chrome) {//Js�ж�Ϊ�ȸ�chrome�����
        return "chrome";
    }
    if (Sys.opera) {//Js�ж�Ϊopera�����
        return "opera";
    }

    if (Sys.safari) {//Js�ж�Ϊƻ��safari�����
        return "safari";
    }

    return "";
}